package Model;

import View.menuLogin;

public class sistemPerpus {

    public static void main(String[] args) {
        String test = "test";
        
        new menuLogin().setVisible(true);
    }
    
}
