package Model;

public interface Info {
    void info();
}
